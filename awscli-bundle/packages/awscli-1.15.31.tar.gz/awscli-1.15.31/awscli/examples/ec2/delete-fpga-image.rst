**To delete an Amazon FPGA image**

This example deletes the specified AFI.

Command::

  aws ec2 delete-fpga-image --fpga-image-id afi-06b12350a123fbabc

Output::

  {
    "Return": true
  }
